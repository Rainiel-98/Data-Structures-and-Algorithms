#include "OPS.h"
#include "ui_OPS.h"  // This is still correct, as it's the generated header file

OPS::OPS(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form),  // Initialize ui with new Ui::Form
    queueModel(new QStringListModel(this)),
    stackModel(new QStringListModel(this))
{
    ui->setupUi(this);  // This sets up the widgets from the Form

    // Set up models for list views
    ui->listView_6->setModel(queueModel);   // Queue display
    ui->listView_5->setModel(stackModel); // Stack display

    // Connect buttons to slot functions
    connect(ui->push, &QPushButton::clicked, this, &OPS::onPushClicked);
    connect(ui->pop, &QPushButton::clicked, this, &OPS::onPopClicked);
    connect(ui->peek2, &QPushButton::clicked, this, &OPS::onPeekStackClicked);
    connect(ui->enqueue, &QPushButton::clicked, this, &OPS::onEnqueueClicked);
    connect(ui->dequeue, &QPushButton::clicked, this, &OPS::onDequeueClicked);
    connect(ui->peek1, &QPushButton::clicked, this, &OPS::onPeekQueueClicked);
}

OPS::~OPS()
{
    delete ui;
}


void OPS::updateQueueView() {
    QStringList queueItems;
    queue<int> tempQueue = orderQueue.getQueue();  // Copy queue for safe iteration

    while (!tempQueue.empty()) {
        queueItems << QString::number(tempQueue.front());
        tempQueue.pop();
    }

    queueModel->setStringList(queueItems);  // Update model with queue contents
}

void OPS::updateStackView() {
    QStringList stackItems;
    stack<int> tempStack = orderStack.getStack();  // Copy stack for safe iteration

    while (!tempStack.empty()) {
        stackItems << QString::number(tempStack.top());
        tempStack.pop();
    }

    stackModel->setStringList(stackItems);  // Update model with stack contents
}

// Slot implementations for button actions
void OPS::onPushClicked() {
    int orderID = ui->textEdit_5->toPlainText().toInt();
    orderStack.push(orderID);
    ui->textEdit_5->clear();
    updateStackView();  // Refresh stack view
}

void OPS::onPopClicked() {
    orderStack.pop();
    updateStackView();  // Refresh stack view
}

void OPS::onPeekStackClicked() {
    int topValue = orderStack.peek();
    if (topValue != -1)
        ui->textEdit_5->setPlainText(QString::number(topValue));
}

void OPS::onEnqueueClicked() {
    int orderID = ui->textEdit_5->toPlainText().toInt();
    orderQueue.enqueue(orderID);
    ui->textEdit_5->clear();
    updateQueueView();  // Refresh queue view
}

void OPS::onDequeueClicked() {
    orderQueue.dequeue();
    updateQueueView();  // Refresh queue view
}

void OPS::onPeekQueueClicked() {
    int frontValue = orderQueue.peek();
    if (frontValue != -1)
        ui->textEdit_5->setPlainText(QString::number(frontValue));
}
