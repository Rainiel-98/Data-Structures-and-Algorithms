#ifndef STACK_H
#define STACK_H

#include <stack>  // Include the stack header
using namespace std;

class Stack {
private:
    stack<int> stackArray;  // Declare stack of integers

public:
    void push(int value) { stackArray.push(value); }
    void pop() { if (!stackArray.empty()) stackArray.pop(); }
    int peek() const { return stackArray.empty() ? -1 : stackArray.top(); }
    stack<int> getStack() const { return stackArray; }  // Return a copy of the stack for iteration
};

#endif // STACK_H

